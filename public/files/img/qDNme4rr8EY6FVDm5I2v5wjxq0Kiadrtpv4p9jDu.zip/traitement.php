<?php

function verify_phonenumber($phone){

    if (strlen($phone)>8){
        echo "numero depasse les 8 chiffres";
        return false;
    }

    if (strlen($phone)<8){
        echo "numero moins de 8 chiffres";
        return false;
    }

    if (!ctype_digit($phone)){
        echo "le nombre n'est pas compose de chiffres";
        return false;
    }
    return true;
}

function verify_all($nom,$prenom,$password1,$passowrd2,$email,$phone){

    if (!strlen($nom)){
        echo "le nom est vide";
        return false;
    }

    if (!strlen($prenom)){
        echo "le prenom est vide";
        return false;
    }

    if((strlen($password1))<8){
        echo "la longeur du mot de passe est inferieure à 8";
    }

    if(strcmp($password1,$passowrd2)){
        echo "mot de passe ne sont pas identiques";
        return false;
    }

    if (!verify_phonenumber($phone)){
        return false;
    }


    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo("l'adresse n'est pas valide");
        return false;
    }

    return true;


}




if (isset($_POST['nom'])&&
    isset($_POST['prenom'])&&
    isset($_POST['password1'])&&
    isset($_POST['password2'])&&
    isset($_POST['email'])&&
    isset($_POST['phone'])) {


    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $mdp1 = $_POST['password1'];
    $mdp2 = $_POST['password2'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    if (verify_all($nom,$prenom,$mdp1,$mdp2,$email,$phone)) {


        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "custom_db";

        $conn = new mysqli($servername, $username, $password, $dbname);

        $sql = "INSERT INTO my_table (nom, prenom, mdp,mail,tel)
        VALUES ('$nom', '$prenom', '$mdp1','$email','$phone')";


        if ($conn->query($sql) === TRUE) {
            echo "nouvel enregistrement affecte";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();

        header("Refresh: 2; url=index.php");
    }

    else{

        header("Refresh: 2; url=index.php");
    }
}