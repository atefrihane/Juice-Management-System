<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>


<script lang="javascript">
    function emailIsValid (email) {
        return /\S+@\S+\.\S+/.test(email)
    }

    function phoneIsValid(str) {
        var patt = new RegExp(/^\+?1?\s*?\(?\d{3}(?:\)|[-|\s])?\s*?\d{3}[-|\s]?\d{4}$/);
        return patt.test(str);
    }

    /*

    function valide() {

        if (document.forms.f1.nom.value.length == 0 ){
            window.alert('nom est vide');
            return false;
        }

        if (document.forms.f1.prenom.value.length ==0 ){
            window.alert('prenom est vide');
            return false;
        }

        if (document.forms.f1.password1.value.length < 6){
            window.alert('mot de passe inferieur a 6');
            return false;
        }

        if (document.forms.f1.password1.value != document.forms.f1.password2.value){
            window.alert('mot de passes ne sont pas identiques');
            return false;
        }

        if (document.forms.f1.phone.value.toString().match(/^[0-9]+$/) == null) {
            window.alert('numero de telephone contient des lettres');
            return false;
        }

        if (document.forms.f1.phone.value.length != 8) {
            window.alert('numero de telephone ne contient pas 8 chiffres');
            return false;
        }

        if (!phoneIsValid(emailIsValid(document.forms.f1.email.value.toString()))){
            window.alert('mail est invalide');
            return false;
        }



        return true;

    }

    */



</script>
<form name ="f1" action="traitement.php" method="post" onsubmit="return valide()">

    <input type="text" name="nom" placeholder="nom"/>
    <br>
    <br>
    <input type="text" name="prenom" placeholder="prenom"/>
    <br>
    <br>
    <input type="password" name="password1" placeholder="taper mot de passe"/>
    <br>
    <br>
    <input type="password" name="password2" placeholder="retaper mot de passe"/>
    <br>
    <br>
    <input type="text"  name="phone" placeholder="taper numero de telephone">
    <br>
    <br>
    <input type="mail" name="email" placeholder="adresse mail">
    <br>
    <br>
    <input type="submit" value="valider"/>

    <input type="reset" value="annuler"/>

</form>
<a  href="display.php" >Affichage</a>




<?php





?>








</body>
</html>