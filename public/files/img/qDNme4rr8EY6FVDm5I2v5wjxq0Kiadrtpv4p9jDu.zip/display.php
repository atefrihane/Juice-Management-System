<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Display Data</title>
</head>
<body>
<style>
    table, th, td {
        border: 1px solid black;
    }
</style>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "custom_db";

$conn = new mysqli($servername, $username, $password, $dbname);

$sql="SELECT * FROM my_table";
$result = $conn->query($sql);


?>

<table>
    <tr>
        <th>nom</th>
        <th>prenom</th>
        <th>mail</th>
        <th>telephone</th>
    </tr>
        <?php
        if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row['nom']."</td>".
           " <td>".$row['prenom']."</td>"
            ."<td>" .$row['mail']."</td>"
            ."<td>" .$row['tel']."</td>";
            echo "</tr>";
           }
        } else {

            echo "<td>pas de données</td>";
            echo "<td>pas de données</td>";
            echo "<td>pas de données</td>";
            echo "<td>pas de données</td>";
        }?>
</table>
<a href="http://localhost/test/">retour</a>
</body>
</html>